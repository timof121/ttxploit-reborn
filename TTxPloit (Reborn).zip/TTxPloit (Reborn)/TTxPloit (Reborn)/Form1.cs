﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace TTxPloit__Reborn_
{
    public partial class Form1 : Form
    {
        ExploitAPI api = new ExploitAPI();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            api.LaunchExploit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string script = richTextBox1.Text;
            api.SendLuaScript(script);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string script1 = richTextBox2.Text;
            api.SendLuaCScript(script1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string target = textBox1.Text;
            api.TeleportMyCharacterTo(target);
        }


        private void button5_Click_1(object sender, EventArgs e)
        {
            api.ToggleClickTeleport();
        }
    }
}
